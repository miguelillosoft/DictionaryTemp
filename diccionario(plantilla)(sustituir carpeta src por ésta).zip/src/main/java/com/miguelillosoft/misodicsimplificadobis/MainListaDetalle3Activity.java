package com.miguelillosoft.misodicsimplificadobis;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;


public class MainListaDetalle3Activity extends FragmentActivity implements InterfacePersonaSeleccionada {
	//METODO DE LA INTERFAD
	@Override
	public void onPersonaSelect(item str) {
		// TODO Auto-generated method stub
		
		   
		/*FragmentFoto fFoto =(FragmentFoto) getSupportFragmentManager().findFragmentById(R.id.fragmentFoto);
		fFoto.cambiarFoto(AsignarFoto(str));*/
		FragmentDetalle3 fDetalle=(FragmentDetalle3) getSupportFragmentManager().findFragmentById(R.id.fragmentDetalle3);
		fDetalle.cambiarTexto(str.getDescripcion());
	}
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_lista_detalle3);
		Fragment_Lista3 LISTA =
				(Fragment_Lista3) getSupportFragmentManager().findFragmentById(R.id.fragmentLista3);
		LISTA.setListener(this);
        Button btnSalir=(Button)findViewById(R.id.btnSalir);
        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        
    }
/*
    public Drawable AsignarFoto(item str){
    	Drawable foto = null;
    	
    	if(str.getName().compareTo("Paquito")==0){
    		foto = getResources().getDrawable(R.drawable.foto1);
    	}else if(str.getName().compareTo("Nona")==0){
    		foto = getResources().getDrawable(R.drawable.foto2);
    	}else if(str.getName().compareTo("Pedro")==0){
    		foto = getResources().getDrawable(R.drawable.foto3);
    	}else if(str.getName().compareTo("Lunares")==0){
    		foto = getResources().getDrawable(R.drawable.foto4);
    	}
    	return foto;
    }
*/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


}

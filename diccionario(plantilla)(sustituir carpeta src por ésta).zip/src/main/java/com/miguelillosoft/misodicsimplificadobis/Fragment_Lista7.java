package com.miguelillosoft.misodicsimplificadobis;


import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;



public class Fragment_Lista7 extends Fragment {
	//INTERACTUACION CON LA INTERFAD
	private InterfacePersonaSeleccionada listener;

    //setter del interface (herencia)
    public void setListener(InterfacePersonaSeleccionada listener) {
        this.listener=listener;
    }



	private ListView listado;

	Fragment_Lista7 flist;
	FragmentDetalle fdetalle;
	//FragmentFoto fFoto;

    //Fuente de datos
    private item[] datos =new item[]{
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),
            new item("bla ", "0 - 0 - 0 ", "bla=bla,bla,bla,bla,bla "),

    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
 
        return inflater.inflate(R.layout.listado, container, false);
    }

    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
 
        listado = (ListView)getView().findViewById(R.id.lista);
        listado.setAdapter(new AdapterList(this,datos));
        
        listado.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> list, View view, int pos, long id) {
                if (listener!=null) {
                    listener.onPersonaSelect(datos[pos]);

                }
            }
        });
    }

    //Adaptador de la lista
public class AdapterList extends ArrayAdapter<item> {
        Activity context;
        item[] lista;

        AdapterList(Fragment context, item[] lista) {
            super(context.getActivity(), R.layout.list_item, lista);
            this.context = context.getActivity();
            this.lista=lista;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
        	LayoutInflater inflater = context.getLayoutInflater();
        	View item = inflater.inflate(R.layout.list_item, null);

        	TextView name = (TextView)item.findViewById(R.id.nombre);
        	name.setText(lista[position].getName());

        	TextView ape = (TextView)item.findViewById(R.id.apellidos);
        	ape.setText(lista[position].getApellidos());



        return(item);
        }
    }
}

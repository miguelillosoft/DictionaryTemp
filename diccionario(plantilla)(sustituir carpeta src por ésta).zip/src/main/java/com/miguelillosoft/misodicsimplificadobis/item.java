package com.miguelillosoft.misodicsimplificadobis;

public class item {
	private String name;
	private String apellidos;
	private String descripcion;
	
	
	
	public item(String name, String apellidos, String descripcion) {
		super();
		this.name = name;
		this.apellidos = apellidos;
		this.descripcion = descripcion;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}

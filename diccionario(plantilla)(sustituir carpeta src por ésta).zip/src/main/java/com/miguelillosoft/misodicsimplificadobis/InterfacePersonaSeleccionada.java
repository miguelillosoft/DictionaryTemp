package com.miguelillosoft.misodicsimplificadobis;

public interface InterfacePersonaSeleccionada {
	public void onPersonaSelect(item str);
}
